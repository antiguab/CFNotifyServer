###################################
#
# EVM Automate Method: fake_execute
#
# Notes: pretends to run a method for 3 seconds 

# Required inputs: status
#
###################################

begin
  @method = 'fake_execute'
  $evm.log("info", "#{@method} - EVM Automate Method Started")

  #sleep method
  $evm.log("info", "#{@method} - actually sleeping for 3 seconds....")
  sleep(3.0)
  #
  # Exit method
  #
  $evm.log("info", "#{@method} - EVM Automate Method Ended")
  exit MIQ_OK

  #
  # Set Ruby rescue behavior
  #
rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
