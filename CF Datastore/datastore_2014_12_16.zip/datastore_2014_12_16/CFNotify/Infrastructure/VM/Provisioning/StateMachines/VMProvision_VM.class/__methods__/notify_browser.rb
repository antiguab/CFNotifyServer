###################################
#
# EVM Automate Method: notify_browser
#
# Notes: This method  adds a request to the chrome / firefox extension server

# Required inputs: status
#
###################################

require 'json'
require 'httpclient'


begin
  @method = 'notify_browser'
  $evm.log("info", "#{@method} - EVM Automate Method Started")

  # Initialize variables
  prov = $evm.root['service_template_provision_task']
  
  # Get status from input field status
  status = $evm.inputs['status']
  
  $evm.log("info", "#{@method} -user: #{prov.userid}")
  $evm.log("info", "#{@method} -requestID: #{prov.miq_request_id}")
  $evm.log("info", "#{@method} -status: #{status}")
  
  http =  HTTPClient.new()
  headers = { 'Accept' => 'application/json', "Content-Type" => "application/json" }
  
  #get user
  resp = http.get("http://still-everglades-1007.herokuapp.com/users/search/#{prov.userid}",["Content-Type", "application/json"]).content
  user = JSON.parse(resp)
  $evm.log("info", "#{@method} -user: #{resp}")

  #get request
  resp = http.get("http://still-everglades-1007.herokuapp.com/requests/search/#{prov.miq_request_id}",["Content-Type", "application/json"]).content
  $evm.log("info", "#{@method} -request 1st attempt: #{resp}")

  #if it's null that means we need to create the request
  if resp.eql? "null"
     body = {
       :cfid => prov.miq_request_id,
       :user_id => user["id"]
        }.to_json
      resp = http.post("http://still-everglades-1007.herokuapp.com/requests",body,headers).content
    $evm.log("info", "#{@method} -request 2nd attempt: #{resp}")
  end
  
  request = JSON.parse(resp)
  
  #post status
  body = {
    	:request_id => request["id"],
    	:content => status
       }.to_json
  resp = http.post("http://still-everglades-1007.herokuapp.com/statuses",body,headers).content
  $evm.log("info", "#{@method} -status: #{resp}")

  #send to pusher
  body = {
    	:request_id => request["cfid"],
    	:status => status,
    	:user => prov.userid
       }.to_json
  resp = http.post("http://still-everglades-1007.herokuapp.com/notify/index",body,headers).content
    
  #
  # Exit method
  #
  $evm.log("info", "#{@method} - EVM Automate Method Ended")
  exit MIQ_OK

  #
  # Set Ruby rescue behavior
  #
rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
