#
# Description: This method launches the service provisioning job
#

$evm.log("info", "Listing Root Object Attributes:")
$evm.root.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}") }
$evm.log("info", "===========================================")
def dump_root()
  $evm.log(:info, "Root:<$evm.root> Begin $evm.root.attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log(:info, "Root:<$evm.root> Attribute - #{k}: #{v}")}
  $evm.log(:info, "Root:<$evm.root> End $evm.root.attributes")
  $evm.log(:info, "")
end

def dump_current()
  $evm.log(:info, "Current:<$evm.current> Begin $evm.current.attributes")
  $evm.current.attributes.sort.each { |k, v| $evm.log(:info, "Current:<$evm.current> Attribute - #{k}: #{v}")}
  $evm.log(:info, "Current:<$evm.current> End $evm.current.attributes")
  $evm.log(:info, "")
end

dump_root
dump_current

$evm.log("info", "Listing Task Attributes: #{$evm.root["service_template_provision_task"].inspect}")
$evm.root["service_template_provision_task"].execute
